public class Book {
    public int bookID;
    public int bookValue;

    public Book(int ID, int value) {
        this.bookID = ID;
        this.bookValue = value;
    }
}
